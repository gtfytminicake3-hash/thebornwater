# Missing Decode Evidence List

## Priority 1: Core Systems Architecture
- **Save/Load Format**: Exact schema for `SaveLoadUtility` (Is it JSON, binary, or ES3?). How are `BuildingInstance` and `AIAgent` states serialized?
- **Day/Night Continuous Time**: Exact length of a day in real-time seconds (`DayNightController.dayDuration`?). Time progression curve and precise triggers for Evening/Night.
- **Physical Grid / Pathfinding**: Dimensions of the world map, grid size, and NavMesh/A* setup used by `AIAgent`.

## Priority 2: Data Extraction (ScriptableObjects)
- **Building Costs & Requirements**: Exact numeric values inside `BuildingData` (e.g., `labourRequiredToBuild`, `numberOfResourcesRequired`, `res1`, `quantity1`).
- **Job Production Rates**: Exact output per tick/delivery in `JobData`.
- **Enemy Stats**: Health, attack, speed, and spawn weights in `EnemyData`.
- **Global Balance Limits**: Food consumption rate, starvation damage, default storage capacities.

## Priority 3: UI and Frontend Flow
- **Original Layout Structure**: Position and prefab structure of the HUD (Resource bars, Build Menu, Action Panel).
- **Player Input Flow**: Event sequence when the player clicks "Build Hut" in the original UI (Does it spawn a ghost prefab on the cursor?).
- **Job Assignment UI**: How does the player assign villagers to jobs? (Is there a global list, or do they click the building and press an "Add Worker" button?).

## Priority 4: Visuals & Audio
- **Particle Systems & VFX**: Exact prefabs and triggers for combat hits, bonfire smoke, and construction dust.
- **Audio Mapping**: FMOD Event strings/paths for UI clicks, building completion, ambient tracks, and combat sounds.

**Status Summary**: Until these pieces of evidence are extracted from `data.unity3d` or `global-metadata.dat`, any numeric implementation must be strictly labeled as `UNKNOWN` or `PROTOTYPE_FALLBACK`.
