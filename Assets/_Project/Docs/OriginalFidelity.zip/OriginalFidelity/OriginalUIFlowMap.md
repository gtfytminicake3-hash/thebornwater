# Original UI Flow Map

## Current UI Buttons Classification
- **NEW GAME**: ORIGINAL_CONFIRMED (MainMenu logic exists)
- **LOAD GAME**: ORIGINAL_CONFIRMED (SaveManager exists)
- **+10 WOOD**: DEBUG_ONLY
- **ASSIGN WORKER**: PROTOTYPE_FALLBACK
- **BUILD HUT / STORAGE / GUARD TOWER**: PROTOTYPE_FALLBACK (UI flow is fallback; original likely uses a `BuildMenu` popup with categories)
- **NEXT TIME**: DEBUG_ONLY
- **SAVE GAME**: DEBUG_ONLY (Original probably auto-saves at morning or in pause menu)
- **FORCE RAID**: DEBUG_ONLY
