# Building Construction Runtime Fidelity Report

## 1. Objective
Refactor the temporary instant-build fallback to properly follow decoded construction mechanics found in the original game data (specifically `BuildingInstance.currentCompletion`, `BuildingInstance.finalCompletion`, `DepositResource`, and `UpdateConstruction`).

## 2. Implemented Logic
- `GameSnapshot`'s `TaskSnapshot` was expanded to store required resources, deposited resources, and current/final completion integer states.
- The `LocalGameBackend` no longer deducts total resource cost and bypasses construction upon calling `BuildHutCommand`, `BuildStorageCommand`, or `BuildGuardTowerCommand`. 
- Instead, building placement initiates a construction site that automatically simulates `DepositResource` ticks by transferring physical resources from global stockpiles into the `depositedResources` pool phase by phase until the requirement is met.
- Once resources are verified (`isResourcesComplete = true`), idle `Builder` units contribute `addedLabour` points (default 50) each turn to `currentCompletion` until it eclipses `finalCompletion` and the building is officially created.

## 3. Fidelity Boundaries & Fallbacks
- The overall mechanism explicitly tracks the original concept but the following precise variables remain marked as `PROTOTYPE_FALLBACK` or `UNKNOWN` until exact numeric tables are recovered:
    - **Builder Contribution**: Exactly how many `addedLabour` points a builder applies per loop is set to 50.
    - **Final Completion Goal**: Hardcoded to `constructionRequired` from data (which itself is 100).
    - **Deposit Rate**: Currently moves resources to maximum available, simulating instant carrier deliveries rather than physical pathing.

## 4. Conclusion
The construction sequence is fundamentally aligned with the decoded evidence structure. All metrics and UI layouts reflect this multi-step requirement.

**Status: ORIGINAL_BUILDING_CONSTRUCTION_PARTIAL_WITH_UNKNOWN_BALANCE**
