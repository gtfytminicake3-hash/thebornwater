# Original vs Prototype Feature Matrix

| Feature | Original Decode | Current Prototype Fallback | Action Required for FidelityMode |
| :--- | :--- | :--- | :--- |
| **Game Time** | Continuous loop via `DayNightController` | Discrete phases (Morning/Afternoon/Evening/Night) triggered by `NEXT TIME` | Move discrete time to `PrototypeMode` / `DebugTool`. Implement continuous tick loop based on time delta. |
| **Movement** | `AIAgent` using `NavMesh` or A* on physical 2D grid | Simulated entirely in backend arrays with no physical coordinates | Implement 2D Grid / World bounds and Agent physical pathing. |
| **Construction** | 1. Place site ghost<br>2. `DepositResource`<br>3. `AIAgent` assigns labor<br>4. Reaches `finalCompletion` | Arrays map required resources and `ProcessTimeAdvance` applies global fallback builder logic | Keep new construction logic, but attach it to physical agents and physical resource carrying. |
| **Job Assignment** | Contextual UI (click building -> assign/remove worker) | `ASSIGN WORKER` single button cycles one worker randomly | Remove `ASSIGN WORKER` button. Map actual building inspection UI and `JobData` arrays. |
| **Combat** | `CharacterManager` spawns physical enemies that walk and attack targets | `ProcessRaidCheck()` uses simple math phase comparison (`attack` vs `totalDefense`) | Remove phase math combat. Implement real `EnemyInstance` logic chasing `VillagerInstance`. |
| **Testing Cheats** | Not present in player UI | `+10 WOOD`, `FORCE RAID`, `NEXT TIME` | Move these entirely to a `Unity Editor Test Tool` or Developer Overlay. Do NOT display to players. |
| **Storage Limits** | Read from `BuildingData` (e.g., `capacityBonus`) | Hardcoded fallback arrays in `LocalGameBackend.cs` | Extract exact limits from ScriptableObjects and bind to `ResourceStorageBuilding` instances. |
