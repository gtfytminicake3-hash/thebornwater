# Original Building / Construction Evidence

## Confirmed Symbols
- **Class**: `BuildingInstance`, `BuildingDetails`, `HutBuilding`, `BonfireBuilding`, `GuardTower`, `ResourceStorageBuilding`
- **Field**: `currentCompletion`, `finalCompletion`, `labourRequiredToBuild` (in `BuildingDetails`), `numberOfResourcesRequired` (in `BuildingDetails`), `requiredResources` (in `BuildingInstance`)
- **Method**: `DepositResource`, `UpdateConstruction(int addedLabour, AIAgent agent)`, `HasEnoughResourcesToStartConstruction()`
- **Evidence location**: `dump.cs.txt` (TypeDefIndex: 3586 for `BuildingInstance`, TypeDefIndex: 3729 for `BuildingDetails`)

## Confirmed Original Behaviors
- **What is clearly confirmed**: Construction is a multi-step process. A site must be placed, workers must deposit resources (`DepositResource`), and then a builder (`AIAgent`) must contribute labor (`UpdateConstruction`) over time until `currentCompletion` matches `finalCompletion`.
- **What is partially confirmed**: We know jobs like `Builder` and methods for assigning agents exist, but the exact sequence of how agents are assigned via the UI is partially obscured.
- **What is unknown**: The exact integer amount of `addedLabour` contributed per tick/phase, the exact `finalCompletion` (labor required) for each building, and the exact exact numeric resource costs (stored in undecoded `ScriptableObject` assets).

## Hut Behavior
- **Does original Hut instant-complete?** NO
- **Does original Hut use construction progress?** YES
- **Does original Hut require resource deposit?** YES
- **Does original Hut require builder/labour/agent?** YES

## Current Implementation Comparison
- **Current behavior**: Instant completion upon pressing Build. Resources are instantly deducted, and the completed building is immediately spawned.
- **Matches original**: NO
- **Required replacement**: Must replace instant-build with a `TaskSnapshot` representing a construction site that accepts resource deposits over time, requires builder jobs to increment progress, and completes only when finished.

## Missing Evidence
- **exact cost**: UNKNOWN / MISSING_FROM_CURRENT_DECODE (Balance data)
- **exact finalCompletion**: UNKNOWN / MISSING_FROM_CURRENT_DECODE
- **exact builder labour amount**: UNKNOWN / MISSING_FROM_CURRENT_DECODE
- **exact UI flow**: UNKNOWN / MISSING_FROM_CURRENT_DECODE
