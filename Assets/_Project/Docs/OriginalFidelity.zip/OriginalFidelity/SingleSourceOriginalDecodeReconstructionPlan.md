# Single Source Original Decode Reconstruction Plan

## Project Goal
To rebuild "The Bonfire 2: Uncharted Shores" strictly and solely from its decoded origin data, extracting the original backend architecture, numeric balance, UI flow, and visual assets without inventing custom mechanics or relying on placeholder playable logic.

## Non-Negotiable Rules
1. **Decode Fidelity Only**: Do not invent gameplay, UI flow, backend behavior, or numbers.
2. **Strict Segregation**: If evidence is missing, use `UNKNOWN`, `MISSING_FROM_CURRENT_DECODE`, or strictly partition the fallback into `PROTOTYPE_FALLBACK`.
3. **No Fake Originality**: Never claim a prototype fallback as the original game loop.
4. **Tooling over Cheats**: Debug features must reside in developer-only tools, never in the player-facing UI.

## Current Work Audit Summary
The project successfully established a foundational Unity pipeline, integrated decoded art/sprites, and mapped the basic C# symbol structure (via IL2CPP dumps). However, the implementation of the core game loop (`LocalGameBackend`, discrete time phases, instant assignment UI) was built as a playable prototype rather than an exact reverse-engineering of the original physical systems (e.g., `DayNightController`, `AIAgent`, NavMesh). This sprint acknowledges those fallbacks and mandates a transition to true fidelity.

## Current Work Disposition Table
*(See `Assets/_Project/Docs/OriginalFidelity/CurrentWorkDispositionTable.csv` for the full breakdown.)*
- **Keep**: Imported original assets, data definition schemas, and multi-step construction state.
- **Rewrite**: Backend runtime loop (move from discrete math to continuous physical simulation), UI routing.
- **Move to Debug Tool**: Action Panel cheat buttons (`+10 WOOD`, `NEXT TIME`, `FORCE RAID`, `ASSIGN WORKER`).
- **Remove**: Mock backend stubs, fake JSON balance numbers.

## Evidence Sources
1. **Asset Bundle Dumps**: `resources/com.xigmaGames.thebonfire2.apk/assets/bin/Data/data.unity3d` (Visuals, Prefabs).
2. **Metadata**: `global-metadata.dat` (Type strings).
3. **Assembly Code**: `libil2cpp.so` (Game logic DLLs extracted via Il2CppDumper to `dump.cs.txt`).
4. **Audio Banks**: `Master.bank`, `Master.strings.bank`.

## Fidelity Labels
- `KEEP_AS_ORIGINAL_CONFIRMED`: Verifiably matches IL2CPP dumps or extracted Unity metadata.
- `KEEP_AS_DECODE_EVIDENCE_PARTIAL`: Structure is known, but exact parameters (like numbers) are missing.
- `PROTOTYPE_FALLBACK`: Invented logic meant only for testing. Must be purged from FidelityMode.
- `UNKNOWN_NEEDS_MORE_DECODE`: Functionality whose source origin is entirely obscured.

## FidelityMode vs PrototypeMode
**FidelityMode**:
- Uses ONLY verified behavior, data, UI, and assets.
- Absolutely NO debug buttons visible.
- If data is unknown, the game must fail gracefully or log missing data, rather than faking it.

**PrototypeMode**:
- Exists strictly to test mechanical connections.
- Cheats (`+10 Wood`, `Skip Time`) are permitted but MUST be sandboxed within the Unity Editor or a hidden `DebugOverlay`.
- Must never be compiled as the "Final Game".

## Debug/Test Tool Policy
To preserve the purity of the UI, all manual overrides must be placed in a **Unity Editor Window** or a developer-only debug script. 
Allowed Tools (Debug Only):
- Advance simulation tick
- Skip to Night
- Add test resources
- Assign test builder
- Progress selected construction
- Trigger raid test
- Reset save
- Print current snapshot

## System-by-System Reconstruction Plan

### Building / Construction
- **Evidence needed**: `BuildingData` (cost, size), `BuildingInstance` exact flow.
- **Current status**: `DECODE_EVIDENCE_PARTIAL` (Backend tracks multi-step, but uses fake phase math).
- **Plan**: `Rewrite` to require an actual `AIAgent` arriving at the physical grid location to trigger `UpdateConstruction(addedLabour)`.
- **Acceptance Gate**: Building only completes when a physical Builder pathfinds to it and hammers.

### Villager / Job / AIAgent
- **Evidence needed**: `CharacterManager`, `AIAgent` state machine, `JobData`.
- **Current status**: `PROTOTYPE_FALLBACK` (Villagers are just backend array integers).
- **Plan**: `Rewrite`. Implement NavMesh/A* grid movement. Villagers must spawn as physical entities.
- **Acceptance Gate**: Villagers walk to assigned locations.

### Resource Production
- **Evidence needed**: `ResourceData`, `ResourceInstance`, `DepositResource()`.
- **Current status**: `PROTOTYPE_FALLBACK` (Instant phase math).
- **Plan**: `Rewrite`. Resources only increment when a carrier physically drops them at a Storage building.
- **Acceptance Gate**: Visual resource transport loop.

### UI / Frontend Flow
- **Evidence needed**: Original Canvas prefabs, Button routing map.
- **Current status**: `PROTOTYPE_FALLBACK` (Custom Action Panel).
- **Plan**: `Remove` action panel. Implement original contextual popups (click building -> show stats).
- **Acceptance Gate**: UI visually and mechanically matches the original game screens.

### Time / DayNight / Survival
- **Evidence needed**: `DayNightController` constants, `GameBalance` food limits.
- **Current status**: `PROTOTYPE_FALLBACK` (Discrete Morning/Night steps).
- **Plan**: `Rewrite` into a continuous `Update()` loop with physical lighting changes.
- **Acceptance Gate**: Day transitions naturally over real-time seconds.

### Combat / Raid
- **Evidence needed**: `EnemyData`, combat formulas, `CharacterManager` raid spawners.
- **Current status**: `PROTOTYPE_FALLBACK` (Phase math subtraction).
- **Plan**: `Rewrite` into physical entity collisions.
- **Acceptance Gate**: Monsters physically walk on screen and attack Villagers.

### Save / Load
- **Evidence needed**: `SaveLoadUtility` format.
- **Current status**: `PROTOTYPE_FALLBACK` (Custom JSON).
- **Plan**: Investigate if it uses ES3 or binary. `Rewrite` if format is found, else keep fallback in `PrototypeMode`.
- **Acceptance Gate**: Save files match the original game's save extension/structure.

### Asset / Scene / Prefab
- **Current status**: `ORIGINAL_CONFIRMED`.
- **Plan**: Continue using `AssetStudio` to dump raw textures and mapping them into Unity.

### Audio
- **Evidence needed**: FMOD Studio banks.
- **Plan**: Extract `Master.bank` via FMOD bank tools to map original SFX events.
- **Acceptance Gate**: Original UI click and ambient sounds play.

### World Runtime Binding
- **Plan**: Connect the physical `TownScene` logic to the reconstructed `DataRepository`.

## Missing Evidence List
*(See `Assets/_Project/Docs/OriginalFidelity/MissingDecodeEvidenceList.md`)*
Key blockers: Exact ScriptableObject balance numbers, exact length of continuous time ticks, exact Save formatting.

## Implementation Order
1. **Phase 1**: Deprecate Action Panel into Unity Editor Debug Tool.
2. **Phase 2**: Decode/Extract exact Balance/Data definitions from `data.unity3d`.
3. **Phase 3**: Implement continuous `DayNightController` loop.
4. **Phase 4**: Implement physical grid, `AIAgent`, and `NavMesh` movement.
5. **Phase 5**: Connect Resource and Job logic to physical agents.

## Acceptance Gates
- **Phase 1**: No prototype buttons visible on Play.
- **Phase 2**: `buildings.json` contains real numbers from decode.
- **Phase 3**: Time flows without button clicks.
- **Phase 4**: Entities move on screen.

## What Must Not Be Claimed As Original Yet
- Any numeric value in `balance.json`, `resources.json`, `buildings.json` (Currently fallback).
- The "Morning/Afternoon/Evening/Night" discrete phase system.
- The global resource math subtraction mechanics.

## Next Immediate Sprint Recommendation
**Sprint: Debug Tool Migration & UI Cleansing**
- Move the current Action Panel into a custom Unity Editor Window (e.g., `Tools > Rebuild > Game State Debugger`).
- Strip the `TownScene` Canvas of all fallback UI, leaving only the verified Resource Bar and original imported static assets.
