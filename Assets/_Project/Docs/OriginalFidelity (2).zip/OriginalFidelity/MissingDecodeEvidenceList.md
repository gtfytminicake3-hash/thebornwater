# Missing Decode Evidence
- Deposit sequence
- finalCompletion numbers
- labourRequiredToBuild numbers
- Job UI flow